import React, { Component } from "react";
import {
  StyleSheet,
  ProgressBarAndroid ,
  View,
} from "react-native";
import {  Header, List, ListItem, Left, Body, Right, Thumbnail,Container, Spinner, Button, Text,Content, Card, CardItem, Row} from 'native-base';
import Icon  from 'react-native-vector-icons/MaterialCommunityIcons';


export default class HomeScreen extends Component {
  constructor(props){
    super(props);
    this.state = {
      renderCoponentFlag: false,
      items : [
        {name:'Momiii Sent',done:"false"},
        {name:'Cuteiii Sent',done:"false"},
        {name:'Cutieee Sent',done:"false"},
        {name:'Momiii Done',done:"false"},
        {name:'Cuteiii Done',done:"false"},
        {name:'Cutieee Done',done:"false"},
      ],
      status:"ues",
      sentCount:0,
      receiveCount:0,
      showTheThing:false,
    }
  }
  componentDidMount() {
    setTimeout(() => {this.setState({renderCoponentFlag: true})}, 0);
  }
  doThis = () =>{
    // var loginLink = "https://www.dreamindiadream.com/AndroidApp_Handler/Account-login.ashx";
    // var loginDataCuteiii = "txtPasswordSU=tubelight143&txtUserID=D27088&";
    // var loginDataMe = "txtPasswordSU=myangel143&txtUserID=D48293&";
    // var loginDataMom = "txtPasswordSU=Rag1234&txtUserID=D58951&";
    var submitAdd = "https://www.dreamindiadream.com/AndroidApp_Handler/Save-Promotional-Task.ashx?Account-ID=";
    var submitID = ["RDI3MDg4","RDQ4Mjkz","RDU4OTUx"];
    var addClickedID = [
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzcyMTczNDM3MjQ= &",addNO:"1"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzU1NDkwMzg4MzY= &",addNO:"2"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzk0NTUzOTMyMDU= &",addNO:"3"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzYxODUxNDc4Njk= &",addNO:"4"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzUyMDU4NDg5MzA= &",addNO:"5"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzgzMTg2NzI0MDI= &",addNO:"6"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzkwODEwODk3Mzg= &",addNO:"7"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzU0MTExMjIyNDM= &",addNO:"8"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzYyNjMzNTQ3MDg= &",addNO:"9"},
      {addID:"AdsId=Y2EtYXBwLXB1Yi0zOTk1OTYwNjc0NzEwOTkyLzM4NTA2Mjg1NjI= &",addNO:"10"},
    ];
    var This = this;
    var i = 0 ;
    var j = 0;
    submitID.forEach(function(userID){
        addClickedID.forEach(function(addID){
          i+= 1;
          console.log("executing 30/"+i);
          //console.log("id:"+userID+"---"+addID.addID+" ("+addID.addNO+") "+"-->executing 30/"+i);
          var data = addID.addID;

          var xhr = new XMLHttpRequest();
          xhr.withCredentials = true;
          
          xhr.addEventListener("readystatechange", function () {
            if (this.readyState === 4) {

              if(this.responseText == '{"Success":false,"Message":"already clicked","detail":"10","aid":null}'){
                j+=1;
                This.setState({
                  receiveCount:j,
                });
                console.log(this.responseText);
                if(j==10){
                  This.setState({
                    items : [
                      {name:'Momiii Sent',done:"true"},
                      {name:'Cuteiii Sent',done:"true"},
                      {name:'Cutieee Sent',done:"true"},
                      {name:'Momiii Done',done:"true"},
                      {name:'Cuteiii Done',done:"false"},
                      {name:'Cutieee Done',done:"false"},
                    ],
                  });
                  console.log("mom done "+j);
                } 
                console.log("cueiiiiiiiii done "+j);
                if(j==20){
                  This.setState({
                    items : [
                      {name:'Momiii Sent',done:"true"},
                      {name:'Cuteiii Sent',done:"true"},
                      {name:'Cutieee Sent',done:"true"},
                      {name:'Momiii Done',done:"true"},
                      {name:'Cuteiii Done',done:"true"},
                      {name:'Cutieee Done',done:"false"},
                    ],
                  });
                  console.log("cutiee done "+j);
                } 
                

                if(j==30){
                  This.setState({
                    items : [
                      {name:'Momiii Sent',done:"true"},
                      {name:'Cuteiii Sent',done:"true"},
                      {name:'Cutieee Sent',done:"true"},
                      {name:'Momiii Done',done:"true"},
                      {name:'Cuteiii Done',done:"true"},
                      {name:'Cutieee Done',done:"true"},
                    ],
                  });
                  console.log("cueiiiiiiiii done "+j);
                }
              }
              
            }
          });
          
          xhr.open("POST", "https://www.dreamindiadream.com/AndroidApp_Handler/Save-Promotional-Task.ashx?Account-ID="+userID);
          xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
          
          
          xhr.send(data);

          // this.setState({
          //   

          // });
          This.setState({
            sentCount:i,
        });
          if(i%10==0){
            This.setState({
              items : [
                {name:'Momiii Sent',done:"true"},
                {name:'Cuteiii Sent',done:"true"},
                {name:'Cutieee Sent',done:"true"},
                {name:'Momiii Done',done:"false"},
                {name:'Cuteiii Done',done:"false"},
                {name:'Cutieee Done',done:"false"},
              ],
            });
          }
        });  
    });

  }
  render() {
  
    const {renderCoponentFlag} = this.state;

    if(renderCoponentFlag){
      return(
        <Container>
          <Content>
            <Card>
              <CardItem>
                  <Button bordered dark onPress={()=>{
                       this.setState({
                         showTheThing:true
                       }); 
                       this.doThis()
                  }}>
                    <Text>Start</Text>
                  </Button>
                  <View style={styles.containerProgress}>
                    <ProgressBarAndroid
                      styleAttr="Horizontal"
                      indeterminate={false}
                      progress={(this.state.sentCount+this.state.receiveCount)/60}
                      color="#2196F3"
                    />
                    <View style={{flexDirection:"row",alignContent:"space-between"}}>
                        <Text style={{flex:1}}>{this.state.sentCount+this.state.receiveCount}/60</Text>
                        <Text style={{flex:1}}>{parseInt((this.state.sentCount+this.state.receiveCount)/60)*100}%</Text>
                    </View>


                  </View>
              </CardItem>
            </Card>
            <List dataArray={this.state.items}
              renderRow={(item) =>
                <ListItem>
                  <Left>
                    <Text>{item.name}</Text>
                  </Left>
                  <Right>
                  { 
                    this.state.showTheThing && 
                    <Status status={item.done}/>
                  } 
                  </Right>
                  
                </ListItem>
              }>
            </List>
            
          </Content>
        </Container>
      );
    }else{
      return (
        <View style={styles.loder}>
        <Spinner  color='blue'/>
        </View>
      );
    }
  }
}
class Status extends Component{
  constructor(props){
    super(props);
    this.state = {
     
    }
  }
  render(){
    if(this.props.status == "true"){
      console.log(this.props.status);
      return(
        <Icon name="check" style={{color:'#5fd64b', fontSize:30, fontWeight:800}}/>
      );
    }else{
      console.log(this.props.status);

      return(
        <Spinner color = "blue"/>
      );
    }
  }
}
const styles = StyleSheet.create({
  loder: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center'
  },
  containerProgress:{
    flex: 1,
    justifyContent: "space-evenly",
    padding: 10
  }
});